
1. What are SSL and TLS, and how do they differ?

SSL (Secure Sockets Layer) and TLS (Transport Layer Security) are security protocols that protect internet communication.

They encrypt the data exchanged between a client (like a web browser) and a server, preventing attackers from intercepting or tampering with it.

Main differences:

SSL is the older protocol and is now obsolete.

TLS is the modern replacement, offering stronger security and better performance.

Today, the term “SSL certificate” is still commonly used, but it actually refers to a TLS certificate.

2. Why is HTTPS safer than HTTP?

HTTP transmits data in plain text, which means anyone monitoring the connection (e.g., on public Wi-Fi) can read it.

HTTPS is HTTP combined with SSL/TLS, providing:

✅ Encryption – protects sensitive data such as login details and payment information.
✅ Authentication – confirms that the site you’re connecting to is genuine.
✅ Data Integrity – ensures information isn’t altered during transmission.

Example:

HTTP request: username=alice&password=12345 → visible to an attacker.

HTTPS request: Data is encrypted → attacker sees only unreadable text.

3. Risks of not using SSL/TLS in web applications

Without SSL/TLS, you face:

Data theft: Sensitive information (passwords, credit card numbers) can be stolen.

Man-in-the-Middle (MITM) attacks: Hackers can intercept and alter traffic.

Phishing or impersonation: Users can’t verify if they’re on the real website.

SEO penalties: Search engines rank non-HTTPS sites lower.

Browser warnings: Modern browsers flag HTTP sites as “Not Secure,” discouraging visitors.

4. Real-world cases of missing or misconfigured SSL

Equifax (2017): Part of their massive breach was due to unencrypted internal systems exposing sensitive data.

Panama Papers (2016): Mossack Fonseca’s client portals ran on outdated SSL/TLS, making them vulnerable.

Tesco Bank (2016): Weak SSL implementation allowed attackers to commit fraud.

Cloudflare “Cloudbleed” (2017): A misconfiguration caused leaks even over HTTPS, showing that poor SSL setup can still be risky.